/**
 * Created by JetBrains PhpStorm.
 * User: dongyancen
 * Date: 12-4-12
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
module( 'ui.editorui' );
test( '', function() {
    equal('','','');
} );