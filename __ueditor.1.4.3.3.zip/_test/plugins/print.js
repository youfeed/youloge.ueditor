/**
 * Created by JetBrains PhpStorm.
 * User: dongyancen
 * Date: 12-9-28
 * Time: 下午1:34
 * To change this template use File | Settings | File Templates.
 */
module('plugins.print');

test('print',function(){
//    var editor = te.obj[0];
//    var html = '<p>for print</p>';
//    editor.setContent(html);
//    editor.execCommand('print');
//    equal(editor.body.innerHTML,html,'打印不会对页面代码产生影响');
    equal('','');
});
