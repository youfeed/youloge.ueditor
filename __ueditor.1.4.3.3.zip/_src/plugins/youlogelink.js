/**
 * 插入超链接 - 支持任何协议
 * @youloge 
 * 替换原有额link
 */
UE.plugins['links'] = function(){
  // 最佳化
  function optimize( range ) {
    var start = range.startContainer,end = range.endContainer;
    if ( start = domUtils.findParentByTagName( start, 'a', true ) ) {
      range.setStartBefore( start );
    }
    if ( end = domUtils.findParentByTagName( end, 'a', true ) ) {
      range.setEndAfter( end );
    }
  }
  // 
  function doLink(){

  }
  // 弹窗链接
  UE.commands['onlink'] = {
    execCommand:function(){
      console.log('onlink');
    }
  }
  // 取消链接
  UE.commands['unlink'] = {
      execCommand : function() {
          var range = this.selection.getRange(),
              bookmark;
          if(range.collapsed && !domUtils.findParentByTagName( range.startContainer, 'a', true )){
              return;
          }
          bookmark = range.createBookmark();
          optimize( range );
          range.removeInlineStyle( 'a' ).moveToBookmark( bookmark ).select();
      },
      queryCommandState : function(){
          return !this.highlight && this.queryCommandValue('link') ?  0 : -1;
      }
  };
  // 插入链接
  UE.commands['link'] = {
    execCommand : function( cmdName, opt ) {},
    queryCommandValue:function(){}
  }
}